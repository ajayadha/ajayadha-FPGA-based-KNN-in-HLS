/*
 * KNN Implementation in C
 * --------------Ajaykumar Adha
 * --------------Himanshu patra
 * --------------Reconfigurable Computing Systems
 */
//Including this header file enables us to exploit the stream interfaces
#include <hls_stream.h>
#include <ap_axi_sdata.h>
//A header file inclusion where our functions are declared explicitly
#include "functions8.h"
//This inclusion enables to define integer variable as desired bit
#include<ap_int.h>
// Declare 32-bit integer with side-channel (Includes TLAST signal)
typedef ap_axis<32,2,5,6> intSdCh;
void knn_final_8(hls::stream<intSdCh> &inStream,hls::stream<intSdCh> &outStream)
{
//Declaring Out stream as AXI stream Interface
#pragma HLS INTERFACE axis port=outStream
//Declaring In stream as AXI stream Interface
#pragma HLS INTERFACE axis port=inStream
//Declaring control interface if IP to control the clocks and reset of the IP Core
#pragma HLS INTERFACE s_axilite port=return bundle=ctrl
//The temp array is used to store first 8 dimensions of reference row
unsigned int temp[8]={0,0,0,0,0,0,0,0};
//The temp1 array is used to store all the other rows after the computation of distance the array is re-written
unsigned int temp1[8]={0,0,0,0,0,0,0,0};
//Declaring a variable as 64 bit Unsigned Integer
ap_uint<64>  temp2=0;
//setting the maximum values into the temp3 array i.e., KNN array (sorted array)
 ap_uint<64>  temp3[10] = {6871737960000,6871737960000,6871737960000,6871737960000,6871737960000,6871737960000,6871737960000,6871737960000,6871737960000,6871737960000};
//Declaring the inputs as 32 bit integer with side channel
intSdCh valIn;
intSdCh valOut;
//Setting the random indexes into the index array
unsigned int index [10] = {10,10,10,10,10,10,10,10,10,10};
//Count variable is to increment the index when a new row is accessed
unsigned int count =0;
//taking the reference array values
for ( unsigned int i = 0; i < 8; i++)
{
//#pragma HLS PIPELINE
		valIn=inStream.read();
		temp[i]=valIn.data;
}
//taking all the other values and storing in the temp1 array
	for( unsigned int j=0;j<65536;j++)
{
//#pragma HLS PIPELINE
		for(unsigned int k=0;k<8;k++)
		{

			valIn=inStream.read();
		temp1[k]=valIn.data;
		}
		//sending the values to distance function to calculate distance and store every distance in the same temp2
		temp2 = distance(temp1,temp);
		//sort1 sorts the KNN array which has indices
		sort1(temp2,temp3,count,index);
		//Incrementing the Index after the row accessed
		count=count+1;
}
//Writing the Indices as output to the Output stream
	for(unsigned int y1=0;y1<9;y1++)
	{
		//assigning TLast to 1 whenever we are write the last value on to the stream or else it is zero
		if(y1==8)
			valOut.last=1;
		else
			valOut.last=0;
	valOut.data=index[y1];
	outStream.write(valOut);
	valOut.keep = valIn.keep;
	valOut.strb = valIn.strb;
	valOut.user = valIn.user;
	valOut.id = valIn.id;
	valOut.dest = valIn.dest;
	}

}
//Function definition of ditance returns the distance between two rows
ap_uint<64>  distance( unsigned int a[8] , unsigned int b[8])
{
	 ap_uint<64>  d =0;
	 ap_uint<64>  dist =0;
	for (unsigned int m=0;m<8;m++)
		{
#pragma HLS unroll factor=8
		d=((a[m]-b[m])*(a[m]-b[m]));
		dist=dist+d;
		}
 return dist;
}
/*
 * Instead of Sorting A swapping Algorithm is used
 * In this function the incoming distance (temp_eg) is stored as 10th element of temp3 array
 * And Count is stored as 10th element of Index Array
 * Every time a New distance is computed It is checked with all elements of the temp3 array
 * and swaps its position with the same if its magnitude is less.
 * The indices of the rows are swapped Accordingly.
 * So,In Worst Case, # of Comparisons required for each distance are 9, which are very less when compared to bubble sort.
 * It is a void function ,So it doesn't have a return value but changes the array values dynamically.
 * After Computation The Outputs are stored in The Index Array and are sent to the Output stream.
 */
void sort1( ap_uint<64>  temp_eg, ap_uint<64>  temp3[], unsigned int count,unsigned int index[])
{
	//checking if incoming distance is lesser than 9th neighbor and replacing it if it is.
	//storing the corresponding index as count

		temp3[9]=temp_eg;
		index[9]=count;

	for (unsigned int p = 0; p < 9; p++)
	{
		/*
		Loop Unrolling is used to reduce latency
		For a for loop of 9 ,At max the loop can be unrolled 9 times, So a factor of 9 is used.
		*/
#pragma HLS unroll factor=9
	       if(temp3[9]<temp3[p])
	       {
	    	   //Swapping the distances as well as Indices
	    	   ap_uint<64>  temp_array = temp3[p];
	                temp3[p] = temp3[9];
	                temp3[9] = temp_array;
	                 unsigned int temp_array2= index[p];
	                index[p] = index[9];
	                index[9] = temp_array2;
	       }

	       }

	}






