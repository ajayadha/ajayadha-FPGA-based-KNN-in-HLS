#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xil_io.h"
#include "xparameters.h"
#include "xpm_counter.h"
#include "dataset8.h"
//#include "functions.h"

int main ()
{
	u32 a[25];
		Xpm_SetEvents(XPM_CNTRCFG2);

	   unsigned int temp[8]={0};
	  unsigned int temp1[8]={0};
	 long long int temp2=0;
 int count = 0;
 long long int d = 0;
//setting the maximum values into the temp3 array i.e., KNN array (sorted array)
 long long int temp3[10] = {68717379600,68717379600,68717379600,68717379600,68717379600,68717379600,68717379600,68717379600,68717379600,68717379600};
	 int index [10] = {10,10,10,10,10,10,10,10,10,10};

	//taking the reference array values
	for ( unsigned int i = 0; i < 8; i++)
{
		temp[i]=(*(data+i));
}
	//taking all the other values and storing in the temp1 array
	for( unsigned int j=8;j<65535;j++)
{    d = 0;

//#pragma HLS PIPELINE
		for(unsigned int k=0;k<8;k++)
		temp1[k]=(*(data+(8*(j-7)+k)));

			for (unsigned int m=0;m<8;m++)
				{
				d = d + ((temp1[m]-temp[m])*(temp1[m]-temp[m]));
				}


		//sort1 sorts the KNN array which has indices
		//sort1(temp2,temp3,count,index);


		temp3[9]=d;
			index[9]=count;


				for (int p = 0; p < 9; p++)
				{
				       if(temp3[9]<temp3[p])
				       {
				    	   long long int temp_array = 0;
				    	    	temp_array = temp3[p];
				                temp3[p] = temp3[9];
				                temp3[9] = temp_array;
				                int temp_array2 = 0;
				                temp_array2 = index[p];
				                index[p] = index[9];
				                index[9] = temp_array2;
				       }

				       }



		count=count+1;
}

	for(unsigned int y1=0;y1<9;y1++)
	{
xil_printf("Nearest NEighborfrom software[%d] is %d \n\r",y1,index[y1]);

	}
	Xpm_GetEventCounters(a);
	xil_printf("read cycles is %u\n\r",*a);
	xil_printf("write cycles is %u\n\r",*(a+1));
	return 0;
}
