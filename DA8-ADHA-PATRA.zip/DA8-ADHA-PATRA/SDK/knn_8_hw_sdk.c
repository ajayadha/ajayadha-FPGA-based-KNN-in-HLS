
int main()
{
	int i;
	u32 reg;
	u32 *optr = NULL;
    init_platform();

    print("--- Calculating gains ----- \n\r");

    // Start address of the destination values. (DDR address)
    u32 rx_buffer = 0x0A000000;
    u32 *outputbuf= (u32*)(rx_buffer);
    UINTPTR Inaddr = (UINTPTR)(mydata);
    UINTPTR Outaddr= (UINTPTR)(outputbuf);

    printf("-- Input array address %p\n\r", mydata);
    printf("-- Output Array address %p\n\r", outputbuf);

  //Configure KNN_8
XKnn_final_8_WriteReg(XPAR_XKNN_FINAL_8_0_S_AXI_CTRL_BASEADDR, XKNN_FINAL_8_CTRL_ADDR_AP_CTRL, 1);

    // Setup DMA
    // Reset the MM2S and S2MM DMA interfaces
    XAxiDma_WriteReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_RX_OFFSET + XAXIDMA_CR_OFFSET, XAXIDMA_CR_RESET_MASK);
    XAxiDma_WriteReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_TX_OFFSET + XAXIDMA_CR_OFFSET, XAXIDMA_CR_RESET_MASK);
    // Wait for the Reset to complete
    while((XAxiDma_ReadReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_RX_OFFSET + XAXIDMA_CR_OFFSET) & XAXIDMA_CR_RESET_MASK) == 1) {}
    while((XAxiDma_ReadReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_TX_OFFSET + XAXIDMA_CR_OFFSET) & XAXIDMA_CR_RESET_MASK) == 1) {}
    printf("-- reset done");
    // MM2S DMA Setup
    // Get the value of the present value of the MM2S DMA control register.
    reg = XAxiDma_ReadReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_TX_OFFSET + XAXIDMA_CR_OFFSET);
    // Set the Start DMA bit of the control register
    XAxiDma_WriteReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_TX_OFFSET + XAXIDMA_CR_OFFSET, reg | XAXIDMA_CR_RUNSTOP_MASK);
    // Set the start address from where the DMA has to fetch the data
    XAxiDma_WriteReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_TX_OFFSET + XAXIDMA_DESTADDR_OFFSET, Inaddr);

    // S2MM Setup
    // Similar process as above for the S2MM DMA
    reg = XAxiDma_ReadReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_RX_OFFSET + XAXIDMA_CR_OFFSET);
    XAxiDma_WriteReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_RX_OFFSET + XAXIDMA_CR_OFFSET, reg | XAXIDMA_CR_RUNSTOP_MASK);
    XAxiDma_WriteReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_RX_OFFSET + XAXIDMA_DESTADDR_OFFSET, Outaddr);
    printf("-- setup done");
    // Activate DMA
    // MM2S Activate
    // Writing to the Transfer length register starts the DMA operation. The length has to be specified
    // as number of Bytes to transfer. We have send 65537*8*4 bytes and the length is
    // 2097184 bytes
    XAxiDma_WriteReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_TX_OFFSET + XAXIDMA_BUFFLEN_OFFSET, 2097184);

    // S2MM Activate
    // Write the length of S2MM. This specifies the number of bytes to transfer back to the Memory from
    // the stream interface. Writing to this register starts the S2MM Master DMA.
    XAxiDma_WriteReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_RX_OFFSET + XAXIDMA_BUFFLEN_OFFSET, 36);
    printf("-- transfer done");
    XKnn_final_8_WriteReg(XPAR_XKNN_FINAL_8_0_S_AXI_CTRL_BASEADDR, XKNN_FINAL_8_CTRL_ADDR_AP_CTRL, 1);
    // Wait for both DMAs to complete
    // Poll for the IoC bit to be set in the Status registers for both the DMAs
    while(XAxiDma_ReadReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_TX_OFFSET + XAXIDMA_SR_OFFSET) != 4098) {}
    printf("-- dma transfer done");
    while(XAxiDma_ReadReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_RX_OFFSET + XAXIDMA_SR_OFFSET) != 4098) {}
    printf("-- dma receive done");
    // Clear Status register
    XAxiDma_WriteReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_TX_OFFSET + XAXIDMA_SR_OFFSET, 4098);
    XAxiDma_WriteReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_RX_OFFSET + XAXIDMA_SR_OFFSET, 4098);

    // Print out the outputs.
    printf("-- Printing outputs -- \n\r");
    optr = (u32*)(outputbuf);
    for(i=0;i<9;i++)
    {
    	xil_printf("Outputs from hardware [%d] := %d \n\r",i,*(optr+i));
    	}

    cleanup_platform();
    return 0;
}