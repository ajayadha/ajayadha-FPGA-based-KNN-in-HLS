power intern             


Job Details:

Job Description: 

The Programmable Solutions Group[PSG] has been delivering industry-leading custom logic solutions to customers our product engineers develops process and methodology to qualify the static and dynamic power models for the FPGA products.Your specific responsibilities will include but are not limited to the following: Analysis of FPGA circuits and power domainsGenerate and validate patterns to characterize critical power rails to meet product rollout targets.Conduct statistical analysis of silicon data to guide accurate model adjustments. Rollout of accurate power models that maximize power efficiency under aggressive timelines.Utilize experience in RTL, synthesis & STA tools silicon debug skills and understanding of circuit fundamentals and VLSI processes.

Qualifications:
You must possess the below minimum qualifications to be initially considered for this position. Experience listed below would be obtained through a combination of your school work/classes/research and/or relevant previous job and/or internship experiences. 

Minimum Requirements:

- Must be pursuing a Master degree in Electrical Engineering.
- Minimum of 3 months experience with: RTL VHDL or Verilog coding .Digital design. ASIC design flows synthesis, place & route & timing analysis, static and dynamic power estimation .VLSI process technology for deep submicron.

Preferred Qualifications:

-Experience with performance evaluation and speed / power tradeoffs of large scale integrated circuits.
-Programmable logic & FPGA architecture.

          
Job Type:
Student / Intern

Shift:
Shift 1 (United States of America)

Primary Location: 
US, California, San Jose


Hardware Engineer - Intern 2017   JR0812880



Job Description: 
Job Description: Responsibilities may be quite diverse of a nonexempt technical nature. U.S. experience and education requirements will vary significantly depending on the unique needs of the job. Job assignments are usually for the summer or for short periods during breaks from school.

Qualifications:
BSEE or CEPC architectureSOC architectureHardware debugging



          